const { PubSub } = require("@google-cloud/pubsub");
const mailgun = require("mailgun-js");
const { Sequelize, DataTypes } = require("sequelize");
require("dotenv").config();
const jwt = require("jsonwebtoken");

const sequelize = new Sequelize({
  dialect: "postgres",
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  username: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
});

// Function to generate JWT token
function generateToken(userId) {
  const token = jwt.sign({ userId }, "testing");
  return token;
}

// Define the model for the email_tracking table
const EmailTracking = sequelize.define("EmailTracking", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  email: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  verification_link: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  sent_timestamp: {
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: Sequelize.literal("CURRENT_TIMESTAMP"),
  },
  verification_status: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: false,
  },
  expiry_timestamp: {
    type: DataTypes.DATE,
    allowNull: false,
  },
});

const mg = mailgun({
  apiKey: "fb8713444717c7f784b043a3217ac83a-f68a26c9-f30e7306",
  domain: "kashishdesai.me",
});

// Function to send verification email
async function sendVerificationEmail(email, userId) {
  const token = generateToken(userId);
  const verificationLink = `http://kashishdesai.me:8080/v1/user/verify-email?token=${token}`;

  const mailOptions = {
    from: "info@kashishdesai.me",
    to: "kashishdesai03@gmail.com",
    subject: "Email Verification",
    html: `Please click <a href="${verificationLink}">here</a> to verify your email.`,
  };

  try {
    await mg.messages().send(mailOptions);
    console.log("Verification email sent successfully:", email);
  } catch (error) {
    console.error("Error sending verification email:", error);
    throw error;
  }
}

// Function to generate a verification link with timestamp
/*function generateVerificationLink(email, timestamp) {
  const verificationLink = `https://example.com/verify?email=${email}&timestamp=${timestamp}`;
  return verificationLink;
}*/

// Function to verify if the timestamp is within 2 minutes
/*function isWithinTwoMinutes(timestamp) {
  const currentTime = Date.now();
  return currentTime - timestamp <= 120000; // 120,000 milliseconds = 2 minutes
}*/

// Function to mark user as verified in the database
/*async function markUserAsVerified(email) {
  try {
    const user = await User.findOne({ where: { username: email } });
    if (user) {
      await user.update({ verified: true });
      console.log(`User ${email} marked as verified`);
    } else {
      console.error(`User ${email} not found`);
    }
  } catch (error) {
    console.error(`Error marking user ${email} as verified:`, error);
  }
}*/

// Cloud Function to handle pub/sub messages
exports.verifyEmailFunction = async (message, context) => {
  try {
    console.log("DB_HOST:", process.env.DB_HOST);
    console.log("DB_PORT:", process.env.DB_PORT);
    console.log("DB_USER:", process.env.DB_USER);
    console.log("DB_PASSWORD:", process.env.DB_PASSWORD);
    console.log("DB_NAME:", process.env.DB_NAME);

    const timestamp = Date.now();

    console.log("Received message:", message);

    const data = JSON.parse(Buffer.from(message.data, "base64").toString());
    console.log("Received data:", data);

    // Extract necessary information from the message payload
    const { email, userId } = data;
    console.log("Extracted email:", email);
    console.log("Extracted user id:", userId);

    // Update EmailTracking record
    //await updateEmailTracking(email);

    // Update User record to mark as verified
    //await markUserAsVerified(email);

    const verificationLink = `http://kashishdesai.me:8080/v1/user/verify-email?token=${generateToken(
      userId
    )}`;
    console.log("Generated verification link:", verificationLink);

    // Update EmailTracking record
    await EmailTracking.create({
      email,
      verification_link: verificationLink,
      expiry_timestamp: new Date(timestamp + 2 * 60 * 1000),
    });

    // Send verification email
    await sendVerificationEmail(email, userId);

    console.log(`Verification email sent to ${email}`);
  } catch (error) {
    console.error("Error verifying email:", error);
  }
};
